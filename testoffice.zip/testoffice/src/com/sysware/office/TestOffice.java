package com.sysware.office;


import com.aspose.words.Document;
import com.aspose.words.SaveFormat;

public class TestOffice {
    public void  word2Html(){
        try {
            Document doc = new Document(getMyDir() + "心情日记.docx");
            doc.save(getMyDir()+"心情日记.html", SaveFormat.HTML);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    public String getMyDir() {
        String myDir  = "E:\\tmp\\";

        return myDir;
    }


    public static void main(String[] args) {
        TestOffice office = new TestOffice();
        office.word2Html();
    }

}
